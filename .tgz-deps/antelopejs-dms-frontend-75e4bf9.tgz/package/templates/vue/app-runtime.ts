import UApp from "@nuxt/ui/components/App.vue";
import UIcon from "@nuxt/ui/runtime/vue/components/Icon.vue";
import { useToast } from "@nuxt/ui/composables/useToast";
import { useAppConfig } from "@nuxt/ui/runtime/vue/composables/useAppConfig";
import { en as uiEn, fr as uiFr } from "@nuxt/ui/locale";
import ui from "@nuxt/ui/vue-plugin";
import { router } from "@inertiajs/vue3";
import { useHead } from "@unhead/vue";
import type { VueHeadClient } from "@unhead/vue/types";
import type { IconifyIcon } from "@iconify/vue";
import { parse } from "devalue";
import {
  type App,
  type Component,
  computed,
  defineComponent,
  h,
  type Plugin,
  Suspense,
  type VNode,
  watch,
} from "vue";
import { createI18n, useI18n } from "vue-i18n";
import DmsDynamicPage from "./DmsDynamicPage.vue";
import {
  type DmsLayerAppConfig,
  type DmsLocaleLoader,
  type DmsPageProps,
  type DmsPayload,
  type DmsServerFetch,
  type DmsUser,
  createDmsFrontendRuntime,
  dmsPageSuspenseProps,
  getDmsErrorPage,
  getDmsLayout,
  getDmsLayoutProps,
  getDmsPage,
  hydrateDmsPageProps,
  hydrateDmsSharedProps,
  installDmsPlugins,
  keepSharedOverHistory,
  preloadDmsPage,
  preloadPrefetchedDmsPages,
  provideDmsFrontendRuntime,
  readDmsLocaleCookie,
  resolveDmsAsyncComponents,
  resolveDmsComponent,
  restoreDmsPayload,
  trackDmsAsyncComponents,
  updateDmsAppConfig,
  useDmsAppConfig,
  useDmsState,
  useDmsError,
  useDmsUserSession,
} from "./frontend-module";
import {
  SSR_ICONS_ID,
  addDmsIcons,
  drawLoadedIconsAtOnce,
} from "./icon-hydration";
import {
  catalogLocale,
  loadLocaleMessages,
  localeMessages,
  supportedLocales,
  syncLocaleMessages,
} from "./locales.generated";
import {
  type DmsMessageSubset,
  SSR_MESSAGES_ID,
  recordMessageReads,
} from "./message-subset";
import { NETWORK_ERROR_KEYS, showNetworkErrors } from "./network-error";
import { loadIconBundle } from "./icon-bundle";
import { createUiAppConfigMerger } from "./ui-app-config";

export interface DmsInertiaSetupProps {
  initialPage: unknown;
  initialComponent: Component;
  resolveComponent: (name: string) => Promise<Component>;
  titleCallback?: (title: string) => string;
  onHeadUpdate?: (elements: string[]) => void;
}

export interface DmsAppOptions {
  app: App;
  head: VueHeadClient;
  initialPageProps: DmsPageProps;
  initialPageUrl: string;
  inertiaPlugin: Plugin;
  runtime?: DmsFrontendRuntime;
  serverFetch?: DmsServerFetch;
}

export interface DmsConfiguredApp {
  /**
   * The locale of the catalog the app shows its messages from now, none when
   * the page is served the messages it read alone.
   */
  catalogLocale: () => string | undefined;
  /**
   * On the server, for a page of a visitor who is not signed in: the messages
   * the render read, which the page carries instead of the whole catalog.
   */
  messageSubset: () => DmsMessageSubset | undefined;
  mounted: () => Promise<void>;
  runtime: ReturnType<typeof createDmsFrontendRuntime>;
}

export const DMS_PAYLOAD_ID = "dms-payload";
export const SSR_ASYNC_COMPONENTS_ID = "dms-ssr-async-components";
const DEFAULT_LOCALE = "en";

/**
 * Nuxt UI ships its own strings (placeholders, empty states, aria labels).
 * Only the locales the DMS translates are imported: the full catalog would
 * weigh on every bundle. A locale missing here falls back to English.
 */
const UI_LOCALES = { en: uiEn, fr: uiFr };

type UiLocale = (typeof UI_LOCALES)[keyof typeof UI_LOCALES];

function uiLocale(locale: string): UiLocale {
  return UI_LOCALES[locale as keyof typeof UI_LOCALES] ?? UI_LOCALES.en;
}

/** The supported locale of a user's language, if it has one. */
function userLocale(user: DmsUser | null | undefined): string | undefined {
  const language = user?.language;
  if (typeof language !== "string") return undefined;
  const locale = language.slice(0, 2);
  return supportedLocales.includes(locale) ? locale : undefined;
}

function readServerRendered<T>(
  id: string,
  empty: T,
  parseText: (text: string) => unknown = JSON.parse,
): T {
  if (typeof document === "undefined") return empty;
  const element = document.getElementById(id);
  if (!element?.textContent) return empty;
  const value = parseText(element.textContent) as T;
  element.remove();
  return value;
}

drawLoadedIconsAtOnce();

/** A browser runtime, started from what the server rendered, if it did. */
function createBrowserRuntime(
  serverFetch?: DmsServerFetch,
): DmsConfiguredApp["runtime"] {
  const runtime = createDmsFrontendRuntime(serverFetch);
  // Nothing when the server did not render the page: no hydration then.
  const payload = readServerRendered<DmsPayload | undefined>(
    DMS_PAYLOAD_ID,
    undefined,
    parse,
  );
  if (payload) restoreDmsPayload(runtime, payload);
  return runtime;
}

const DmsInertiaPage = defineComponent({
  name: "DmsInertiaPage",
  inheritAttrs: false,
  setup(_, { attrs }) {
    const props = computed(() => attrs as unknown as DmsPageProps);
    watch(
      () => [attrs.path, attrs.page, attrs.error],
      () => {
        void preloadDmsPage(props.value);
      },
      { immediate: true },
    );
    const { t } = useI18n();
    useHead({
      title: computed(() => {
        const title = props.value.page.route?.displayName;
        return title?.startsWith("$") ? t(title.slice(1)) : title;
      }),
    });
    return () => renderDmsPage(props.value);
  },
});

const DmsPersistentLayout = defineComponent({
  name: "DmsPersistentLayout",
  inheritAttrs: false,
  setup(_, { attrs, slots }) {
    const props = computed(() => attrs as unknown as DmsPageProps);
    const i18n = useI18n();
    const { user } = useDmsUserSession();
    let localeVersion = 0;
    useHead({
      htmlAttrs: { lang: computed(() => i18n.locale.value) },
    });
    watch(
      () => [attrs.path, attrs.page, attrs.user, attrs.session, attrs.error],
      () => hydrateDmsPageProps(props.value),
      { immediate: true, flush: "sync" },
    );
    // Apart from the page: a reload of the site layout alone (`router.reload({
    // only: ["shared"] })`) is not a navigation.
    watch(
      () => attrs.shared,
      () => hydrateDmsSharedProps(props.value.shared),
      { flush: "sync" },
    );
    // The session, not the page props: a page restored from history or from
    // the prefetch cache carries the user as it was when it was fetched, and
    // would switch the interface back to a language the user has left. A
    // session without a language keeps the one on screen.
    watch(
      () => userLocale(user.value),
      async (locale) => {
        const version = ++localeVersion;
        if (!locale || i18n.locale.value === locale) return;
        const messages = await loadLocaleMessages(locale);
        if (version !== localeVersion) return;
        i18n.setLocaleMessage(locale, messages);
        i18n.locale.value = locale;
      },
      { immediate: true, flush: "sync" },
    );
    const currentError = useDmsError();
    const overlays = useDmsState<string[]>("dms-app-overlays", () => []);
    return () => {
      const error = currentError.value ?? props.value.error;
      const content = error
        ? [renderDmsPage(props.value, error)]
        : slots.default?.();
      return renderDmsPersistentLayout(
        props.value,
        error,
        content,
        overlays.value,
        i18n.locale.value,
      );
    };
  },
});

const DmsPersistentInertiaPage = Object.assign(DmsInertiaPage, {
  layout: DmsPersistentLayout,
});

/**
 * What a visit waits for before it shows its page, set when the first one
 * starts from a page that began without what the pages after it read: a
 * subset of the catalog, the icon bundle. Inertia also resolves the first page
 * once the app is set up, which must not wait for it.
 */
let completeInitialAssets: (() => Promise<void>) | undefined;

export function resolveDmsInertiaPage(): Component | Promise<Component> {
  return completeInitialAssets
    ? completeInitialAssets().then(() => DmsPersistentInertiaPage)
    : DmsPersistentInertiaPage;
}

function renderDmsPage(
  props: DmsPageProps,
  capturedError: DmsPageProps["error"] = useDmsError().value,
) {
  const error = capturedError ?? props.error;
  const page = error
    ? (getDmsErrorPage() ?? DmsDynamicPage)
    : (getDmsPage(props) ?? DmsDynamicPage);
  const pageContent = h(page as Component, {
    ...props,
    error,
    key: props.path,
  });
  return h(Suspense, dmsPageSuspenseProps(), { default: () => pageContent });
}

function renderDmsPersistentLayout(
  props: DmsPageProps,
  error: DmsPageProps["error"],
  children: VNode[] | undefined,
  overlays: string[],
  locale: string,
) {
  const layout = error ? undefined : getDmsLayout(props);
  const content = layout
    ? h(layout, getDmsLayoutProps(props), { default: () => children })
    : children;
  return h(
    UApp,
    { portal: "#dms-overlays", locale: uiLocale(locale) },
    {
      default: () => [
        ...overlays.map((name) =>
          h(resolveDmsComponent(name) ?? name, { key: name }),
        ),
        content,
      ],
    },
  );
}

const mergeUiAppConfig = createUiAppConfigMerger();

function mergeDmsAppConfig(): void {
  mergeUiAppConfig(useAppConfig(), useDmsAppConfig());
}

/**
 * Development only: applies the layers' app configs, edited while the page is
 * open, to the DMS app config and to Nuxt UI's, both in place, so the
 * components reading them and Nuxt UI's colors follow without a reload.
 */
export function applyLayerAppConfigs(appConfigs: DmsLayerAppConfig[]): void {
  updateDmsAppConfig(appConfigs);
  mergeUiAppConfig(useAppConfig(), useDmsAppConfig(), { isChanged: true });
}

export async function configureDmsApp(
  options: DmsAppOptions,
): Promise<DmsConfiguredApp> {
  mergeDmsAppConfig();
  const runtime = options.runtime ?? createBrowserRuntime(options.serverFetch);
  // The signed-in user's language, else the one this browser picked, which is
  // how a visitor's choice on a public page survives a reload.
  const locale =
    userLocale(options.initialPageProps.user) ??
    readDmsLocaleCookie(runtime, supportedLocales) ??
    DEFAULT_LOCALE;
  const anonymous = !options.initialPageProps.user;
  const subset = anonymous
    ? readServerRendered<DmsMessageSubset | undefined>(
        SSR_MESSAGES_ID,
        undefined,
      )
    : undefined;
  const started = subset?.locale === locale ? subset : undefined;
  const messages = started?.messages ?? (await loadLocaleMessages(locale));
  const recorder =
    anonymous && typeof window === "undefined"
      ? recordMessageReads(messages)
      : undefined;
  let loading: Promise<void> | undefined;
  const i18n = createI18n({
    legacy: false,
    locale,
    fallbackLocale: DEFAULT_LOCALE,
    messages: started
      ? { [locale]: messages }
      : { ...localeMessages, [locale]: recorder?.messages ?? messages },
    ...(started && {
      missing: (_locale: string, key: string) => {
        if (i18n.global.locale.value !== locale) return key;
        void loadCompleteCatalog();
        return "";
      },
    }),
  });
  function loadCompleteCatalog(): Promise<void> {
    if (i18n.global.locale.value !== locale) return Promise.resolve();
    loading ??= loadLocaleMessages(locale).then(
      (complete) => {
        i18n.global.setLocaleMessage(locale, complete);
        i18n.global.setMissingHandler(null);
      },
      () => {
        loading = undefined;
      },
    );
    return loading;
  }
  if (anonymous && typeof window !== "undefined") {
    const complete = async (): Promise<void> => {
      await Promise.all([
        started ? loadCompleteCatalog() : undefined,
        loadIconBundle(),
      ]);
    };
    router.on("before", () => {
      completeInitialAssets = complete;
      void complete();
    });
    for (const type of ["pointerdown", "keydown", "focusin", "touchstart"])
      addEventListener(type, () => void loadIconBundle(), {
        once: true,
        capture: true,
      });
  }
  if (recorder) for (const key of NETWORK_ERROR_KEYS) i18n.global.te(key);
  // A translation changed in a layer during development reaches the page
  // without a reload. A server render imports the new catalogs instead.
  if (typeof window !== "undefined") syncLocaleMessages(i18n.global);
  provideDmsFrontendRuntime(options.app, runtime);
  options.app.component("Icon", UIcon);
  options.app.use(options.inertiaPlugin).use(options.head).use(ui).use(i18n);
  options.app.runWithContext(() =>
    hydrateDmsPageProps(options.initialPageProps, options.initialPageUrl),
  );
  addDmsIcons(
    readServerRendered<Record<string, IconifyIcon>>(SSR_ICONS_ID, {}),
  );
  if (typeof window !== "undefined") {
    const toast = options.app.runWithContext(() => useToast());
    showNetworkErrors(toast.add, i18n.global);
    preloadPrefetchedDmsPages();
    options.app.runWithContext(keepSharedOverHistory);
  }
  // Resolve, before the app mounts, every async component the server
  // rendered: the page, its layout, and the components the render reached.
  // Hydration then adopts the server-rendered markup instead of discarding it.
  await Promise.all([
    anonymous ? undefined : loadIconBundle(),
    preloadDmsPage(options.initialPageProps),
    resolveDmsAsyncComponents(
      readServerRendered<string[]>(SSR_ASYNC_COMPONENTS_ID, []),
    ),
  ]);
  const mounted = await installDmsPlugins(
    options.app,
    i18n.global,
    runtime,
    loadLocaleMessages as DmsLocaleLoader,
    supportedLocales,
  );
  return {
    catalogLocale: () =>
      recorder ? undefined : catalogLocale(i18n.global.locale.value),
    messageSubset: () => recorder && { locale, messages: recorder.subset() },
    mounted,
    runtime,
  };
}

export { trackDmsAsyncComponents };

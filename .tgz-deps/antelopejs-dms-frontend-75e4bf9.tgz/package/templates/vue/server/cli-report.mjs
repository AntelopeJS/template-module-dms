import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { stripVTControlCharacters } from "node:util";
import { isNumber, isObjectLike, isRecord, isString } from "./type-guards.mjs";

const WILDCARD_ADDRESSES = ["0.0.0.0", "::"];

/**
 * @param {import("node:child_process").Serializable} message
 * @param {string} line
 * @param {(line: string) => void} write
 * @returns {Promise<void>}
 */
async function report(message, line, write) {
  if (!process.send) return write(line);
  /** @type {Promise<void>} */
  const sent = new Promise((resolve) =>
    process.send?.(message, () => resolve()),
  );
  await sent;
}

/**
 * The server answers at `address`:`port`.
 *
 * What the server tells whoever started it. Started by `ajs dms dev` or `ajs
 * dms start`, it reports over IPC and the CLI words what the user reads.
 * Started on its own, it prints the line itself.
 *
 * @param {string} address
 * @param {number} port
 * @returns {Promise<void>}
 */
export async function reportReady(address, port) {
  const host = WILDCARD_ADDRESSES.includes(address)
    ? "localhost"
    : address.includes(":")
      ? `[${address}]`
      : address;
  await report(
    { type: "dms:ready", address, port },
    `✓ Server ready on http://${host}:${port}`,
    console.log,
  );
}

/** The `ANTELOPEJS_QUIET` values that leave a run verbose, as `@antelopejs/core` reads them. */
const DISABLED_FLAG_VALUES = ["0", "false"];

/**
 * Prints the routing summary, unless the run is quiet: `-q` given to `ajs` or
 * `ajs dms` reaches the server as `ANTELOPEJS_QUIET`, and a quiet ready server
 * prints only its `Local` url.
 *
 * @param {readonly string[]} lines What `routingReport` returned
 * @param {NodeJS.ProcessEnv} [env]
 */
export function reportRouting(lines, env = process.env) {
  const quiet = env.ANTELOPEJS_QUIET;
  if (quiet && !DISABLED_FLAG_VALUES.includes(quiet.toLowerCase())) return;
  for (const line of lines) console.log(line);
}

/**
 * The server cannot listen: a port taken by another process, an address this
 * host does not have. Reported instead of Node's unhandled-error dump, then
 * the server exits.
 *
 * @param {NodeJS.ErrnoException} error
 * @param {string} host
 * @param {number} port
 * @returns {Promise<void>}
 */
export async function reportListenError(error, host, port) {
  await report(
    {
      type: "dms:listen-error",
      code: error.code,
      message: error.message,
      host,
      port,
    },
    `DMS server cannot listen on ${host}:${port}: ${error.message}`,
    console.error,
  );
  process.exit(1);
}

/** The `[PARSE_ERROR] ` Rolldown puts in front of what it says. */
const RULE_PREFIX = /^\[[A-Z_]+\]\s*/;

/**
 * The first problem Rolldown reports when it cannot bundle a config.
 *
 * @param {unknown} error What the startup threw
 */
function bundlerError(error) {
  const errors = isObjectLike(error) ? error.errors : undefined;
  const first = isObjectLike(errors) ? errors[0] : undefined;
  return isRecord(first) ? first : undefined;
}

/**
 * Where a startup error points, when it says: Rolldown's location for a config
 * it could not bundle (the line is read back from the file, which Rolldown
 * only draws in a colored frame), Rollup's for a plugin that failed on a file.
 *
 * @param {unknown} error What the startup threw
 */
function errorLocation(error) {
  const source =
    bundlerError(error) ?? (isObjectLike(error) ? error : undefined);
  const loc = isObjectLike(source?.loc) ? source.loc : undefined;
  const file = loc?.file ?? source?.id;
  if (!isString(file)) return undefined;
  const line = isNumber(loc?.line) ? loc.line : undefined;
  return {
    file: resolve(file),
    line,
    column: isNumber(loc?.column) ? loc.column : undefined,
    lineText: line === undefined ? undefined : readLine(file, line),
  };
}

/**
 * Line `line` (1-based) of `file`, `undefined` when it cannot be read.
 *
 * @param {string} file
 * @param {number} line
 * @returns {string | undefined}
 */
function readLine(file, line) {
  try {
    return readFileSync(file, "utf8").split(/\r?\n/)[line - 1];
  } catch {
    return undefined;
  }
}

/**
 * The first line of what went wrong, without Rolldown's rule and frame.
 *
 * @param {unknown} error What the startup threw
 */
function errorText(error) {
  const reported = bundlerError(error);
  const message = reported
    ? String(reported.message)
    : error instanceof Error
      ? error.message
      : String(error);
  return stripVTControlCharacters(message)
    .split(/\r?\n/)[0]
    .replace(RULE_PREFIX, "");
}

/**
 * Vite could not start, so no page can be served: the error and where it
 * points instead of a stack trace, then the server exits.
 *
 * @param {unknown} error What the startup threw
 */
export async function reportStartError(error) {
  const message = errorText(error);
  const location = errorLocation(error);
  const where = location
    ? `${location.file}${location.line ? `:${location.line}:${location.column ?? 0}` : ""}: `
    : "";
  await report(
    {
      type: "dms:start-error",
      message,
      code: isObjectLike(error) ? error.code : undefined,
      location,
    },
    `DMS development server failed to start: ${where}${message}`,
    console.error,
  );
  process.exit(1);
}
